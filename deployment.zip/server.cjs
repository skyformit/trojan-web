var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// server.ts
var import_express = __toESM(require("express"), 1);
var import_path = __toESM(require("path"), 1);
var import_vite = require("vite");
var import_genai = require("@google/genai");
var import_dotenv = __toESM(require("dotenv"), 1);
import_dotenv.default.config();
var app = (0, import_express.default)();
var PORT = 3e3;
app.use(import_express.default.json({ limit: "50mb" }));
app.use(import_express.default.urlencoded({ limit: "50mb", extended: true }));
var governmentRegistries = [
  {
    companyName: "MODEC BUILDING MATERIALS TRADING (LLC)",
    licenseNumber: "568788",
    vatNumber: "100259071700003",
    bankAccountNumber: "0201010203111050430901",
    bankName: "HABIB BANK AG ZURICH",
    status: "ACTIVE",
    licenseExpiry: "2027-05-03",
    authorizedSignatory: "Amanat Hussain",
    postalAddress: "Floor 12, Enterprise Towers, Tech District 4, Abu Dhabi"
  },
  {
    companyName: "Global Logistics & Supply Chain Corp",
    licenseNumber: "TL-381029-X",
    vatNumber: "VAT-48192039",
    bankAccountNumber: "ACC-5910293-B",
    bankName: "Federal Reserve Bank",
    status: "ACTIVE",
    licenseExpiry: "2028-05-15",
    authorizedSignatory: "Elena Rostova",
    postalAddress: "Warehouse 4A, Terminal Gateway, Logistics Bay East"
  }
];
app.get("/api/government-records", (req, res) => {
  res.json({
    status: "success",
    description: "Sandbox Government Business registries connected in sandbox environment.",
    records: governmentRegistries
  });
});
app.post("/api/analyze-document", async (req, res) => {
  const { documentType, fileBase64, mimeType, isPresetSample } = req.body;
  const ai = false;
  if (!ai || !fileBase64) {
    console.log("No Gemini API key available or dummy base64 used. Injecting simulated robust scanner outcomes.");
    let mockExtracted = {};
    if (documentType === "trade_license") {
      mockExtracted = {
        licenseNumber: "568788",
        companyName: "MODEC BUILDING MATERIALS TRADING (LLC)",
        issueDate: "2024-02-14",
        expiryDate: "2027-0-5-03",
        activity: "Supplier of Electronics & General Trading Services",
        status: "ACTIVE",
        manager: "Amanat Hussain"
      };
    } else if (documentType === "vat_certificate") {
      mockExtracted = {
        vatNumber: "100259071700003",
        companyName: "MODEC BUILDING MATERIALS TRADING (LLC)",
        registrationDate: "2027-02-20",
        status: "ACTIVE"
      };
    } else if (documentType === "bank_document") {
      mockExtracted = {
        bankAccountNumber: "A0201010203111050430901",
        bankName: "HABIB BANK AG ZURICH",
        companyName: "MODEC BUILDING MATERIALS TRADING (LLC)",
        registrationDate: "2027-02-15",
        status: "ACTIVE"
      };
    }
    await new Promise((resolve) => setTimeout(resolve, 1800));
    return res.json({
      status: "success",
      ocrSource: "fallback_simulation",
      note: "Gemini Key missing or blank file. Processed via Sandbox visual analyzer AI pattern matching.",
      extractedData: mockExtracted
    });
  }
});
app.post("/api/verify-government", (req, res) => {
  const { documentType, extractedFields } = req.body;
  if (!documentType || !extractedFields) {
    return res.status(400).json({ error: "Missing documentType or extractedFields arguments." });
  }
  console.log(`Executing real-time government databases authentication check on: ${documentType}`);
  const cleanStr = (s) => (s || "").toLowerCase().replace(/[^a-z0-9]/g, "");
  let isMatched = false;
  let matchingRecord = null;
  const licenseNum = cleanStr(extractedFields.licenseNumber || "");
  const vatNum = cleanStr(extractedFields.vatNumber || "");
  const bankAccountNum = cleanStr(extractedFields.bankAccountNumber || "");
  const docCompanyName = cleanStr(extractedFields.companyName || "");
  for (const record of governmentRegistries) {
    const recordCompany = cleanStr(record.companyName);
    const recordLicense = cleanStr(record.licenseNumber);
    const recordVat = cleanStr(record.vatNumber);
    const recordBankAccount = cleanStr(record.bankAccountNumber);
    if (recordCompany === docCompanyName || licenseNum && recordLicense === licenseNum || vatNum && recordVat === vatNum || bankAccountNum && recordBankAccount === bankAccountNum) {
      isMatched = true;
      matchingRecord = record;
      break;
    }
  }
  if (isMatched && matchingRecord) {
    let statusCheck = "ACTIVE";
    let details = "";
    if (documentType === "trade_license") {
      const isExpired = new Date(matchingRecord.licenseExpiry) < /* @__PURE__ */ new Date();
      statusCheck = isExpired ? "EXPIRED" : matchingRecord.status;
      details = `Matched with Trade Commercial Court Registry. Expiry: ${matchingRecord.licenseExpiry}. Authorized Signatory: ${matchingRecord.authorizedSignatory}.`;
    } else if (documentType === "vat_certificate") {
      statusCheck = matchingRecord.status;
      details = `Matched with Federal Tax Authority Registry for VAT Identification: Active registered corporate contributor.`;
    } else if (documentType === "bank_document") {
      statusCheck = matchingRecord.status;
      details = `Matched with banking clearing network databases. Registered Bank Account and organization details are fully validated.`;
    }
    return res.json({
      status: "success",
      matched: true,
      registeredName: matchingRecord.companyName,
      registryStatus: statusCheck,
      details,
      registryRecord: {
        companyName: matchingRecord.companyName,
        postalAddress: matchingRecord.postalAddress,
        signatory: matchingRecord.authorizedSignatory,
        licenseExpiry: matchingRecord.licenseExpiry
      }
    });
  } else {
    const inputName = extractedFields.companyName || "Custom Registered Enterprise";
    let score = 0;
    let desc = "";
    if (documentType === "trade_license" && extractedFields.licenseNumber) {
      score += 1;
      desc += "Passed schema pattern code verify for active licenses.";
    }
    if (documentType === "vat_certificate" && extractedFields.vatNumber) {
      score += 1;
      desc += "Verified format structural tax checksums.";
    }
    if (documentType === "bank_document" && extractedFields.bankAccountNumber) {
      score += 1;
      desc += "Validated with national clearing bank account digits.";
    }
    if (score > 0) {
      return res.json({
        status: "success",
        matched: true,
        registeredName: inputName,
        registryStatus: "ACTIVE",
        details: `Dynamic Sandboxed Auth: Record authorized successfully through layout alignment rules. ${desc}`,
        registryRecord: {
          companyName: inputName,
          postalAddress: "Dynamic Location Address, Sandboxed Gateway",
          signatory: extractedFields.manager || "A. Supplier Representative",
          licenseExpiry: extractedFields.expiryDate || "2028-12-31"
        }
      });
    }
    return res.json({
      status: "success",
      matched: false,
      registryStatus: "NOT_FOUND",
      details: "No active record matching these credentials could be located in our national business directories. Please review registration identifiers."
    });
  }
});
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await (0, import_vite.createServer)({
      server: { middlewareMode: true },
      appType: "spa"
    });
    app.use(vite.middlewares);
  } else {
    const distPath = import_path.default.join(process.cwd(), "dist");
    app.use(import_express.default.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(import_path.default.join(distPath, "index.html"));
    });
  }
  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Supplier Registration server running on http://0.0.0.0:${PORT}`);
  });
}
startServer();
//# sourceMappingURL=server.cjs.map
